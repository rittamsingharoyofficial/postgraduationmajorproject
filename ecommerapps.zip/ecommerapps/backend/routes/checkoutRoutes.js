const express = require("express");
const Cart = require("../models/Cart");
const Checkout = require("../models/Checkout");
const Product = require("../models/Product");
const Order = require("../models/Order");
const { protect } = require("../middleware/authMiddleware");
const router = express.Router();

// @route POST /api/checkout
// @desc Create a new checkout
//@access Private
router.post("/", protect, async (req, res) => {
  const { checkoutItems, shippingAddress, paymentMethod, totalPrice } =
    req.body;
  if (!checkoutItems || checkoutItems.length === 0) {
    return res.status(400).json({ message: "No checkout items!" });
  }
  try {
    //create a new checkout session
    const newcheckout = await Checkout.create({
      user: req.user._id,
      checkoutItems,
      shippingAddress,
      paymentMethod,
      totalPrice,
      paymentStatus: "pending",
      isPaid: false,
    });
    console.log(`Checkout created for user: ${req.user._id}`);
    res.status(201).json(newcheckout);
  } catch (error) {
    console.error("Error creating checkout session:", error);
    res.status(500).json({ message: " Server Error" });
  }
});

//@route PUT /api/checkout/:id/pay
//@desc Update checkout to mark as paid after successful payment
//@access Private
router.put("/:id/pay", protect, async (req, res) => {
  const { paymentStatus, paymentDetails } = req.body;
  try {
    const checkout = await Checkout.findById(req.params.id);
    if (!checkout) {
      return res.status(404).json({ message: "Checkout not found!" });
    }
    if (paymentStatus === "paid") {
      checkout.isPaid = true;
      checkout.paidAt = Date.now();
      checkout.paymentStatus = "paid";
      checkout.paymentDetails = paymentDetails; // store payment details for reference
      await checkout.save();
      res.status(200).json(checkout);
    } else {
      res.status(400).json({ message: "Invalid payment status!" });
    }
  } catch (error) {
    console.error("Error updating checkout payment status:", error);
    res.status(500).json({ message: "Server Error" });
  }
});

//@route POST  /api/checkout/:id/finalize
//@desc Finalize the checkout and converrt it to an order after successful payment
//@access Private

router.post("/:id/finalize", protect, async (req, res) => {
  try {
    const checkout = await Checkout.findById(req.params.id);
    if (!checkout) {
      return res.status(404).json({ message: "Checkout not found!" });
    }
    if (checkout.isPaid && !checkout.isFinalized) {
      const finalorder = await Order.create({
        user: checkout.user,
        orderItems: checkout.checkoutItems,
        shippingAddress: checkout.shippingAddress,
        paymentMethod: checkout.paymentMethod,
        totalPrice: checkout.totalPrice,
        isPaid: checkout.isPaid,
        paidAt: checkout.paidAt,
        isDelivered: false,
        paymentStatus: checkout.paymentStatus,
        paymentDetails: checkout.paymentDetails,
      });
      // Mark the checkout as finalized

      checkout.isFinalized = true;
      checkout.finalizedAt = Date.now();
      await checkout.save();
      //Delete the user's cart after finalizing the order
      await Cart.findOneAndDelete({ user: checkout.user });
      res.status(201).json(finalorder);
    } else if (checkout.isFinalized) {
      res.status(400).json({ message: "Checkout already finalized!" });
    } else {
      res.status(400).json({ message: "Checkout not paid yet!" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
});

module.exports = router;
