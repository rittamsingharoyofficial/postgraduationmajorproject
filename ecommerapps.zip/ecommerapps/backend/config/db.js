const mongoose = require("mongoose");
 const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log("MongoDB connected sucessfully.");
        
    }
    catch (err){
        console.log("MongoDB connection Failed!", err);
        process.exit()
        

    }
 }

 module.exports = connectDB;